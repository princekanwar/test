package com.example.kanwar.finaltest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SQLDatabaseHandler db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new SQLDatabaseHandler(this);
        setContentView(R.layout.activity_main);
    }



    public void onSignUpButtonClicked(View view) {
        Intent intent = new Intent(MainActivity.this, Signup.class);
        startActivity(intent);
    }


    public void onLoginButtonClick (View view) {
        EditText email   = (EditText)findViewById(R.id.email);
        EditText password   = (EditText)findViewById(R.id.password);

        if(email.getText().toString().isEmpty() || password.getText().toString().isEmpty()){
            Toast.makeText(this, "Fill all the fields!",
                    Toast.LENGTH_LONG).show();
        } else {

            User newUser = new User();
            newUser.setEmail(email.getText().toString());
            newUser.setPassword(password.getText().toString());
            System.out.println(newUser.toString());

            if(isUserPresent(newUser)) {
                Intent intent = new Intent(MainActivity.this, ProductsView.class);
                intent.putExtra("IS_GUEST","false");
                startActivity(intent);
            } else {
                Toast.makeText(this, "Wrong email or password",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    public void onGuestButtonClick (View view) {
        Intent intent = new Intent(MainActivity.this, ProductsView.class);
        intent.putExtra("IS_GUEST","true");
        startActivity(intent);
    }

    private Boolean isUserPresent (User user) {
        List<User> users = db.allUsers();

        return users.contains(user);
    }
}


