package com.example.kanwar.finaltest;

/**
 * Created by PRABH on 12/6/2017.
 */
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import java.util.ArrayList;
import android.widget.ListView;
import java.util.List;
import java.util.Arrays;
import android.widget.ArrayAdapter;

public class ProductsView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products_view);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);




        Bundle extras = getIntent().getExtras();
        String isGuest = "false";
        if (extras != null) {
            isGuest = extras.getString("IS_GUEST");
            //The key argument here must match that used in the other activity
        }



        List<Product> products = CreateProducts();


        String[] names = new String[products.size()];
        String[] productDescs = new String[products.size()];

        for (int i = 0; i < products.size(); i++){
            names[i] = products.get(i).getName();
            productDescs [i] = products.get(i).toString();
        }

        // Create a List from String Array elements
        final List<String> names_list = new ArrayList<String>(Arrays.asList(names));

        // Create an ArrayAdapter from List
        final ArrayAdapter<String> arrayAdapterNames = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, names_list);

        // Create a List from String Array elements
        final List<String> product_desc_list = new ArrayList<String>(Arrays.asList(productDescs));

        // Create an ArrayAdapter from List
        final ArrayAdapter<String> arrayAdapterProductDescs = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, product_desc_list);

        // DataBind ListView with items from ArrayAdapter




        ListView myListView = (ListView) findViewById(R.id.listView);



        if(isGuest.equals("true")){
            myListView.setAdapter(arrayAdapterNames);
        } else{
            myListView.setAdapter(arrayAdapterProductDescs);
        }



// Create the adapter to convert the array to views
//        UsersAdapter adapter = new UsersAdapter(this, arrayOfUsers);
//// Attach the adapter to a ListView
//        ListView listView = (ListView) findViewById(R.id.lvItems);
//        listView.setAdapter(adapter);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    private ArrayList<Product> CreateProducts() {
        ArrayList<Product> products = new ArrayList<Product>();

        Product newProduct1 = new Product("Laptops", "20");
        Product newProduct2 = new Product("Mobiles", "50");
        Product newProduct3 = new Product("Printers", "30");
        Product newProduct4 = new Product("Speakers", "15");
        Product newProduct5 = new Product("Tablets", "40");


        products.add(newProduct1);
        products.add(newProduct2);

        products.add(newProduct3);
        products.add(newProduct4);
        products.add(newProduct5);

        return products;
    }


}
