package com.example.kanwar.finaltest;


public class Product {

    String name;


    public Product(String name, String discount){
        this.name = name;
        this.discount = discount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    String discount;

    @Override
    public String toString() {
        return
                "name='" + name + '\'' +
                        ", discount='" + discount + '\'';
    }
}
